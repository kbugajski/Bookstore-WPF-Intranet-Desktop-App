﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookstoreApp.Models.Dtos
{
    public class SearchComboBoxDto
    {
        public string PropteryTitle { get; set; } = default!;
        public string DisplayName { get; set; } = default!;
    }

}
